var Reaact = require('react');
var ReactDOM = require('react-dom');
var List = require('./components/List');

Reaact.render(<List />, document.getElementById('ingredients'));